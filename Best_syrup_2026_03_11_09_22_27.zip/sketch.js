let r = 20
let rows = 5
let balls = []

function setup(){
  createCanvas(400,400)

  let x0 = width/2
  let y0 = height/2
  let dx = 0
  let dy = 0

  for (let row = 0; row < rows; row++){
    let x = x0+row*r*sin(1/3*PI)

    for (let col = 0; col<=row; col++){
      let y = y0-row*r/2+col*r

      balls.push([x,y,dx,dy])
    }
  }
}

function draw() {
  background(220)

  for (let i = 0; i < balls.length; i++) {
    circle(balls[i][0], balls[i][1], r)
  }
}